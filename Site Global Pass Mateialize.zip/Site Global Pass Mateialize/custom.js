document.addEventListener('DOMContentLoaded', function() {
    console.log("entrei no addEventListener")
    var elems = document.querySelectorAll('.carousel');
    var instances = M.Carousel.init(elems, options);
});

jQuery.noConflict()(function ($) { // this was missing for me
    console.log("entrei no noConflict")
    $(document).ready(function(){
        console.log("entrei no js");
        $('.carousel').carousel();
        //$('.fixed-action-btn').openFAB();
        //$('.fixed-action-btn').closeFAB();
    });
});

// $(".card").mouseenter(function (e) {
//     if ($(this).find('> .card-reveal').length) {
//         if ($(e.target).is($('.card .activator')) || $(e.target).is($('.card .activator i'))) {
//             // Make Reveal animate up
//             $(this).find('.card-reveal').css({display: 'block'}).velocity("stop", false).velocity({translateY: '-100%'}, {duration: 300, queue: false, easing: 'easeInOutQuad'});
//         }
//     }

//     $('.card-reveal').closest('.card').css('overflow', 'hidden');

// });

// $(".card").mouseleave(function () {
//     // Make Reveal animate down and display none
//     $(this).find('.card-reveal').velocity(
//             {translateY: 0},
//             {
//                 duration: 225,
//                 queue: false,
//                 easing: 'easeInOutQuad',
//                 complete: function () {
//                     $(this).css({display: 'none'});
//                 }
//             });
// });